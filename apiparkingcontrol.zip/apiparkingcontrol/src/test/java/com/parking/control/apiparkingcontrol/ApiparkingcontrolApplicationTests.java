package com.parking.control.apiparkingcontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiparkingcontrolApplicationTests {

	@Test
	void contextLoads() {
	}

}
