package com.parking.control.apiparkingcontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiparkingcontrolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiparkingcontrolApplication.class, args);
	}

}
